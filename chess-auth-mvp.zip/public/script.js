const API_BASE = '/api/auth';
// Google Identity Services uchun — production'da haqiqiy Client ID bilan almashtiring.
const GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';

const alertBox = document.getElementById('alert');

function showAlert(message, type = 'error') {
  alertBox.textContent = message;
  alertBox.className = `alert ${type === 'success' ? 'success' : ''}`;
  alertBox.hidden = false;
}
function hideAlert() {
  alertBox.hidden = true;
}

function saveSession(token, user) {
  // Eslatma: bu demo sahifa. Haqiqiy ilovada tokenni xavfsizroq joyda
  // (httpOnly cookie yoki platforma-maxsus xavfsiz xotira) saqlash tavsiya etiladi.
  window.__session = { token, user };
}

async function handleAuthResponse(res) {
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Noma\'lum xatolik yuz berdi.');
  }
  return data;
}

function onAuthSuccess(data) {
  saveSession(data.token, data.user);
  const welcomeMsg = data.isNewUser
    ? `Xush kelibsiz, ${data.user.displayName}! Hisobingiz yaratildi.`
    : `Qaytganingizdan xursandmiz, ${data.user.displayName}!`;
  showAlert(welcomeMsg, 'success');
  console.log('Session:', window.__session);
}

// ---------------- Tabs ----------------
const tabs = document.querySelectorAll('.tab');
const panels = { login: document.getElementById('loginForm'), register: document.getElementById('registerForm') };

tabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    tabs.forEach((t) => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
    tab.classList.add('active');
    tab.setAttribute('aria-selected', 'true');
    Object.values(panels).forEach((p) => p.classList.remove('active'));
    panels[tab.dataset.tab].classList.add('active');
    hideAlert();
  });
});

// ---------------- Login form ----------------
document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAlert();
  const btn = e.target.querySelector('button');
  const formData = new FormData(e.target);
  btn.disabled = true;
  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: formData.get('username'),
        password: formData.get('password'),
      }),
    });
    const data = await handleAuthResponse(res);
    onAuthSuccess(data);
  } catch (err) {
    showAlert(err.message);
  } finally {
    btn.disabled = false;
  }
});

// ---------------- Register form ----------------
document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideAlert();
  const btn = e.target.querySelector('button');
  const formData = new FormData(e.target);
  btn.disabled = true;
  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: formData.get('username'),
        password: formData.get('password'),
        displayName: formData.get('displayName'),
        language: navigator.language?.slice(0, 2) || 'uz',
      }),
    });
    const data = await handleAuthResponse(res);
    onAuthSuccess(data);
  } catch (err) {
    showAlert(err.message);
  } finally {
    btn.disabled = false;
  }
});

// ---------------- Telegram WebApp ----------------
const telegramBtn = document.getElementById('telegramBtn');
const tg = window.Telegram?.WebApp;

if (tg) {
  // Telegram ichida ochilgan bo'lsa — avtomatik, bir teginishsiz kirish
  tg.ready();
  telegramBtn.textContent = 'Telegram orqali davom etish';
  telegramLogin(); // auto-login on load inside Telegram
} 

telegramBtn.addEventListener('click', telegramLogin);

async function telegramLogin() {
  hideAlert();
  if (!tg || !tg.initData) {
    showAlert('Bu tugma faqat Telegram Mini App ichida ishlaydi. Botni Telegram orqali oching.');
    return;
  }
  try {
    const res = await fetch(`${API_BASE}/telegram`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initData: tg.initData }),
    });
    const data = await handleAuthResponse(res);
    onAuthSuccess(data);
  } catch (err) {
    showAlert(err.message);
  }
}

// ---------------- Google Identity Services ----------------
window.addEventListener('load', () => {
  if (!window.google?.accounts?.id) return;
  google.accounts.id.initialize({
    client_id: GOOGLE_CLIENT_ID,
    callback: handleGoogleCredential,
  });
  google.accounts.id.renderButton(document.getElementById('googleBtn'), {
    theme: 'filled_black',
    size: 'large',
    shape: 'pill',
    width: 320,
    text: 'continue_with',
  });
});

async function handleGoogleCredential(response) {
  hideAlert();
  try {
    const res = await fetch(`${API_BASE}/google`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ idToken: response.credential }),
    });
    const data = await handleAuthResponse(res);
    onAuthSuccess(data);
  } catch (err) {
    showAlert(err.message);
  }
}
