const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'chess_platform.sqlite'));
db.pragma('journal_mode = WAL');

// Foydalanuvchilar jadvali — bir foydalanuvchi 3 usuldan biri (yoki bir nechtasi) bilan bog'lanishi mumkin
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password_hash TEXT,
    email TEXT UNIQUE,
    telegram_id TEXT UNIQUE,
    telegram_username TEXT,
    google_id TEXT UNIQUE,
    display_name TEXT NOT NULL,
    avatar_url TEXT,
    language TEXT NOT NULL DEFAULT 'uz',
    elo_rating INTEGER NOT NULL DEFAULT 1200,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    last_login_at TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
  CREATE INDEX IF NOT EXISTS idx_users_google_id ON users(google_id);
  CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
`);

module.exports = db;
