const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { OAuth2Client } = require('google-auth-library');
const db = require('../db/database');

const router = express.Router();
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

const SUPPORTED_LANGS = ['uz', 'ru', 'en', 'es', 'de', 'fr', 'tr', 'ar', 'zh', 'hi'];

function signToken(user) {
  return jwt.sign(
    { id: user.id, username: user.username, displayName: user.display_name },
    process.env.JWT_SECRET,
    { expiresIn: '30d' }
  );
}

function publicUser(user) {
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    displayName: user.display_name,
    avatarUrl: user.avatar_url,
    language: user.language,
    eloRating: user.elo_rating,
    hasPassword: !!user.password_hash,
    telegramLinked: !!user.telegram_id,
    googleLinked: !!user.google_id,
  };
}

function normalizeLang(lang) {
  return SUPPORTED_LANGS.includes(lang) ? lang : 'uz';
}

// ---------------------------------------------------------------------------
// 1) USERNAME + PAROL: RO'YXATDAN O'TISH
// ---------------------------------------------------------------------------
router.post('/register', async (req, res) => {
  try {
    const { username, password, displayName, language } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username va parol majburiy.' });
    }
    if (username.length < 3) {
      return res.status(400).json({ error: 'Username kamida 3 belgidan iborat bo\'lishi kerak.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Parol kamida 6 belgidan iborat bo\'lishi kerak.' });
    }

    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) {
      return res.status(409).json({ error: 'Bu username allaqachon band.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const info = db.prepare(`
      INSERT INTO users (username, password_hash, display_name, language, last_login_at)
      VALUES (?, ?, ?, ?, datetime('now'))
    `).run(username, passwordHash, displayName || username, normalizeLang(language));

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
    const token = signToken(user);

    res.status(201).json({ token, user: publicUser(user), isNewUser: true });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Server xatosi. Keyinroq urinib ko\'ring.' });
  }
});

// ---------------------------------------------------------------------------
// 2) USERNAME + PAROL: KIRISH
// ---------------------------------------------------------------------------
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username va parol majburiy.' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user || !user.password_hash) {
      return res.status(401).json({ error: 'Username yoki parol noto\'g\'ri.' });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Username yoki parol noto\'g\'ri.' });
    }

    db.prepare('UPDATE users SET last_login_at = datetime(\'now\') WHERE id = ?').run(user.id);
    const token = signToken(user);

    res.json({ token, user: publicUser(user), isNewUser: false });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server xatosi. Keyinroq urinib ko\'ring.' });
  }
});

// ---------------------------------------------------------------------------
// 3) TELEGRAM WEBAPP: BIR TEGINISHDA KIRISH
// Telegram WebApp `initData` ni tekshirish rasmiy algoritm bo'yicha:
// https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
// ---------------------------------------------------------------------------
function verifyTelegramInitData(initData, botToken) {
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  params.delete('hash');

  const dataCheckArr = [];
  for (const [key, value] of [...params.entries()].sort(([a], [b]) => a.localeCompare(b))) {
    dataCheckArr.push(`${key}=${value}`);
  }
  const dataCheckString = dataCheckArr.join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const computedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

  if (computedHash !== hash) return null;

  // Ma'lumotlar 24 soatdan eski bo'lmasligi kerak (ixtiyoriy, lekin tavsiya etiladi)
  const authDate = Number(params.get('auth_date') || 0);
  const ageSeconds = Math.floor(Date.now() / 1000) - authDate;
  if (ageSeconds > 86400) return null;

  const userJson = params.get('user');
  return userJson ? JSON.parse(userJson) : null;
}

router.post('/telegram', (req, res) => {
  try {
    const { initData } = req.body;
    if (!initData) {
      return res.status(400).json({ error: 'initData yuborilmadi.' });
    }
    if (!process.env.TELEGRAM_BOT_TOKEN) {
      return res.status(500).json({ error: 'Server: TELEGRAM_BOT_TOKEN sozlanmagan.' });
    }

    const tgUser = verifyTelegramInitData(initData, process.env.TELEGRAM_BOT_TOKEN);
    if (!tgUser) {
      return res.status(401).json({ error: 'Telegram ma\'lumotlari tasdiqlanmadi (hash mos kelmadi).' });
    }

    const telegramId = String(tgUser.id);
    let user = db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(telegramId);
    let isNewUser = false;

    if (!user) {
      const displayName = [tgUser.first_name, tgUser.last_name].filter(Boolean).join(' ') || tgUser.username || 'Foydalanuvchi';
      const info = db.prepare(`
        INSERT INTO users (telegram_id, telegram_username, display_name, language, avatar_url, last_login_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `).run(telegramId, tgUser.username || null, displayName, normalizeLang(tgUser.language_code), tgUser.photo_url || null);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
      isNewUser = true;
    } else {
      db.prepare('UPDATE users SET last_login_at = datetime(\'now\'), telegram_username = ? WHERE id = ?')
        .run(tgUser.username || user.telegram_username, user.id);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
    }

    const token = signToken(user);
    res.json({ token, user: publicUser(user), isNewUser });
  } catch (err) {
    console.error('Telegram auth error:', err);
    res.status(500).json({ error: 'Server xatosi. Keyinroq urinib ko\'ring.' });
  }
});

// ---------------------------------------------------------------------------
// 4) GOOGLE OAUTH: ID TOKEN TEKSHIRISH
// Frontend Google Identity Services orqali ID token oladi, biz uni tekshiramiz.
// ---------------------------------------------------------------------------
router.post('/google', async (req, res) => {
  try {
    const { idToken } = req.body;
    if (!idToken) {
      return res.status(400).json({ error: 'idToken yuborilmadi.' });
    }
    if (!process.env.GOOGLE_CLIENT_ID) {
      return res.status(500).json({ error: 'Server: GOOGLE_CLIENT_ID sozlanmagan.' });
    }

    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();

    const googleId = payload.sub;
    let user = db.prepare('SELECT * FROM users WHERE google_id = ?').get(googleId);
    let isNewUser = false;

    if (!user) {
      // Agar shu email bilan boshqa usulda ro'yxatdan o'tgan bo'lsa, hisoblarni bog'laymiz
      const byEmail = payload.email ? db.prepare('SELECT * FROM users WHERE email = ?').get(payload.email) : null;
      if (byEmail) {
        db.prepare('UPDATE users SET google_id = ?, last_login_at = datetime(\'now\') WHERE id = ?').run(googleId, byEmail.id);
        user = db.prepare('SELECT * FROM users WHERE id = ?').get(byEmail.id);
      } else {
        const info = db.prepare(`
          INSERT INTO users (google_id, email, display_name, avatar_url, language, last_login_at)
          VALUES (?, ?, ?, ?, ?, datetime('now'))
        `).run(googleId, payload.email || null, payload.name || 'Foydalanuvchi', payload.picture || null, normalizeLang(payload.locale));
        user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
        isNewUser = true;
      }
    } else {
      db.prepare('UPDATE users SET last_login_at = datetime(\'now\') WHERE id = ?').run(user.id);
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
    }

    const token = signToken(user);
    res.json({ token, user: publicUser(user), isNewUser });
  } catch (err) {
    console.error('Google auth error:', err);
    res.status(401).json({ error: 'Google token tasdiqlanmadi.' });
  }
});

// ---------------------------------------------------------------------------
// 5) JORIY FOYDALANUVCHI MA'LUMOTI (himoyalangan)
// ---------------------------------------------------------------------------
const { requireAuth } = require('../middleware/authMiddleware');

router.get('/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi.' });
  res.json({ user: publicUser(user) });
});

module.exports = router;
