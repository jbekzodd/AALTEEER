# APEX Chess Platform — Foydalanuvchi tizimi va Avtorizatsiya (MVP)

Loyihaning birinchi bosqichi: username/parol, Telegram WebApp va Google OAuth orqali
kirish/ro'yxatdan o'tish tizimi. SQLite baza, JWT sessiya.

## Tuzilma

```
chess-auth/
├── server.js              # Express server
├── db/database.js         # SQLite jadval sxemasi (users)
├── routes/auth.js         # /api/auth/* endpointlar
├── middleware/authMiddleware.js
├── public/                # Demo login/register sahifasi (frontend)
│   ├── index.html
│   ├── styles.css
│   └── script.js
└── .env.example
```

## O'rnatish

```bash
npm install
cp .env.example .env
```

`.env` faylini to'ldiring:

| O'zgaruvchi | Qayerdan olinadi |
|---|---|
| `JWT_SECRET` | O'zingiz tasodifiy uzun matn kiriting (masalan `openssl rand -hex 32`) |
| `TELEGRAM_BOT_TOKEN` | @BotFather'dan bot yaratganda beriladi |
| `GOOGLE_CLIENT_ID` | Google Cloud Console → APIs & Services → Credentials → OAuth 2.0 Client ID (Web application) |

Ishga tushirish:

```bash
npm start
```

Server `http://localhost:3000` da ishga tushadi. Brauzerda oching — login/register sahifasini ko'rasiz.

## API endpointlar

| Metod | Yo'l | Tavsif |
|---|---|---|
| POST | `/api/auth/register` | `{username, password, displayName, language}` |
| POST | `/api/auth/login` | `{username, password}` |
| POST | `/api/auth/telegram` | `{initData}` — Telegram WebApp'dan olinadi |
| POST | `/api/auth/google` | `{idToken}` — Google Identity Services'dan olinadi |
| GET | `/api/auth/me` | Header: `Authorization: Bearer <token>` |

Har bir muvaffaqiyatli javob: `{ token, user, isNewUser }`.

## Telegram WebApp qanday ulanadi

1. Botni Telegram BotFather orqali yarating, `TELEGRAM_BOT_TOKEN`ni oling.
2. BotFather'da bot uchun Menu Button yoki inline tugma orqali WebApp URL sifatida
   sizning `public/index.html` sahifangiz manzilini bering (masalan Render'dagi domen).
3. Foydalanuvchi botni ochib WebApp tugmasini bosganda, `window.Telegram.WebApp.initData`
   avtomatik mavjud bo'ladi — sahifa uni o'zi backend'ga yuboradi va bir teginishda kirish sodir bo'ladi.
4. Backend `TELEGRAM_BOT_TOKEN` yordamida `initData` hashini tekshirib, xavfsizligini kafolatlaydi
   (soxta so'rovlar rad etiladi — bu test qilib ko'rilgan).

## Google OAuth qanday ulanadi

1. Google Cloud Console'da OAuth consent screen va Web application turidagi Client ID yarating.
2. "Authorized JavaScript origins" ga domeningizni qo'shing (masalan `https://sizning-domen.onrender.com`).
3. `public/script.js` faylidagi `GOOGLE_CLIENT_ID` qiymatini almashtiring.
4. `.env` dagi `GOOGLE_CLIENT_ID` ham bir xil qiymat bo'lishi kerak (backend tokenni shu ID bilan tekshiradi).

## Render.com'ga joylashtirish

AgroVet loyihangizga o'xshab:

1. Bu papkani GitHub repo qilib yuklang.
2. Render'da **Web Service** yarating, repo'ni ulang.
3. Build command: `npm install`
4. Start command: `npm start`
5. Environment Variables bo'limiga `.env` dagi 3 ta qiymatni qo'shing.
6. **Diqqat:** SQLite fayli konteyner qayta ishga tushganda o'chib ketishi mumkin —
   Render'da **Persistent Disk** qo'shib, `db/database.js`dagi yo'lni shu diskka
   yo'naltiring (masalan `/data/chess_platform.sqlite`), aks holda foydalanuvchilar
   har deploy'da yo'qoladi.

## Test qilingan holatlar

- ✅ Ro'yxatdan o'tish, login, noto'g'ri parol, band username
- ✅ Telegram `initData` — to'g'ri va soxta hash (soxtasi rad etiladi)
- ✅ JWT bilan himoyalangan `/me` — token yo'q / noto'g'ri / to'g'ri holatlar
- ⏳ Google OAuth — kod tayyor, lekin haqiqiy Google Client ID bilan sizning tomondan
  test qilinishi kerak (bu yerda soxta ID bilan test qilib bo'lmaydi)

## Keyingi qadam

Bu — MVP'ning faqat "Foydalanuvchi identifikatsiyasi" qismi. Keyingi navbatda:
- 10 tillik lokalizatsiya qatlami (hozir faqat uz/ru/en fallback strukturasi bor)
- Onboarding modal oynasi (hashamatli qutlov)
- Ko'nikmalar tahlili jadvali (users jadvaliga bog'lab)
- Shaxmat taxtasi + Minimax dvigateli
